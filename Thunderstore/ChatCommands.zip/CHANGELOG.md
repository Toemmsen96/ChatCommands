## v1.1.2 Important fixes to Spawn functions
- fixed Inside enemies not being the right ones
- fixed scrap spawning issues with error being displayed even if everything worked


## v1.1.1 Improved Host - NonHost communication
- also fixed some prefix stuff

## v1.1.0 Stability and working improvements
- improved stuff to work better


## v1.0.1 Hotfixes and Improvements
- fixed lots of stuff
- added better NonHost to Host communication
- fixed jumpforce when disabling speedhack
- fixed p=@playername command not spawning in the right position

## v1.0.0 Release
- Release

</details>