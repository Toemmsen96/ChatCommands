# ChatCommands
This mod adds some chat commands used with a / by default.
To install either use a mod Manager or just drag thr ChatCommands.dll into your BepInEx/plugins folder.

Commands to use:  
/enemies -> lists spawnable enemies on current map  
/getscrap -> lists spawnable scrap on curent map  
/spawn -> lists what spawn commands you can use  
/spawnscrap or /spwscr "scrapname" (a="amount") (p="position") -> spawn scrap, position can be random, @me or @"playername", with gun as scrapname you can spawn a shotgun  
/spawnenemy or /spweny "enemyname" (a="amount") (p="position") -> spawn enemy, position can be random, @me or @"playername"  
/infammo or /ammo -> enable infinite ammo on shotgun  
/speed -> toggles speed and jump hack for faster travelling  
/god -> toggles godmode  
/tp ("playername") -> teleport back to ship or if  stated to a player  
/buy "item" ("count") -> buy items from shop  
/money -> enables infinite money cheat  
/togglelights -> toggles lights of facility  
/help -> see what commands you can use  
/morehelp -> more commands to use get listed  
/cheats -> list cheat commands  
/credits -> list credits for mod  
/weather -> change weather of current planet (not working properly rn)  
/dl "days" or /deadline "days" -> set amount of days until deadline, gets applied after quota is reached and new one is presented, so reaching the quota once is required. leaving blank after the command will reset to default  
/term -> use Terminal from anywhere. On exiting input you need to type /term again to enable walking again  

Legend:
"arg" -> argument for command you have to enter (without the "")  
(x="arg") -> optional argument you have to write with the x= in front and without the () so it knows what type of argument it is  
